﻿namespace Abc.Data.Common
{
    public abstract class DefinedEntityData : NamedEntityData
    {
        public string Definition { get; set; }
    }
}
