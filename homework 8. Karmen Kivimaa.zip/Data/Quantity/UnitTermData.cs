﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Abc.Data.Quantity
{
    public sealed class UnitTermData : CommonTermData
    {
    }
}
