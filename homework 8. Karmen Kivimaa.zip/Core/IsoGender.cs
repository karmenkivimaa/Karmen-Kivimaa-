﻿namespace Core
{
    public enum IsoGender
    {
        Notknown = 0,
        Male = 1,
        Female = 2,
        NotApplicable = 9
    }
}

