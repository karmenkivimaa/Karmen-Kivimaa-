﻿using Abc.Data.Common;
using Abc.Data.Money;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;

namespace Abc.Tests.Data.Money
{
    [TestClass]
    public class CurrencyDataTests : SealedClassTests<CurrencyData, DefinedEntityData>
    {
    }
}
